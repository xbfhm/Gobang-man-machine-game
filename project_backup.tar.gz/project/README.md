# 五子棋豪华版 v2.0（安卓 16 兼容版）

基于原「Gobang-man-machine-game」大幅升级：**新增 19 项功能**，并针对
**安卓 16（API 36）** 完成打包配置（targetSdk 36 + NDK r28c + 16KB 页大小对齐）。

---

## 🎯 怎么获得 APK（3 步）

1. **上传到 GitHub**：把本文件夹推送到一个 GitHub 仓库（或你的旧仓库）：
   ```
   git init && git add . && git commit -m "gomoku v2.0 android16"
   git remote add origin https://github.com/<你的用户名>/<仓库名>.git
   git push -u origin main
   ```
2. **等待自动打包**：仓库 → `Actions` 页面会运行 `Build APK (Android 16)`
   （约 40~90 分钟，首次会下载 Android SDK/NDK）。
3. **下载 APK**：构建成功后进入该次运行的 `Summary`，下载
   `gomoku16-apk` 构件里的 `gomoku16-2.0-arm64-v8a-debug.apk`，
   传到安卓 16 手机直接安装（需允许“安装未知来源应用”）即可游玩。

> 工作流已内置 **16KB 页大小对齐验证**：会解包 APK 用 `llvm-readelf` 检查
> `lib/*.so` 的 LOAD 段对齐（`2**14` = 16KB 即符合安卓 15/16 + Google Play 要求）。

## 🆕 本次新增功能（19 项）

| # | 功能 | 说明 |
|---|------|------|
| 1 | 棋盘尺寸可选 | 9×9 / 13×13 / 15×15 / 19×19 |
| 2 | 残局挑战模式 | 内置 10 个残局，步数限制 + 自动判胜负 + 提示 |
| 3 | AI 智能提示 | 星标显示 AI 推荐落点；⚡一键 AI 代走 |
| 4 | 威胁点可视化 | 红圈实时标出对方活三/冲四/活四威胁 |
| 5 | 精确禁手检测 | 黑棋长连/双三/双四禁手，正确判负 |
| 6 | 悔棋次数限制 | 0~10 次可配置，面板显示剩余次数 |
| 7 | 对局统计面板 | 分模式胜负平、胜率、连胜、最佳连胜 |
| 8 | 成就系统 | 9 个成就，解锁弹窗 |
| 9 | 对局自动保存/恢复 | 退出后下次可继续 |
| 10 | 完整棋谱回放 | SGF 载入 + 播放/暂停/步进/×2 变速 |
| 11 | 程序生成音效 | 落子/胜利/失败/悔棋音，无需外部音频 |
| 12 | 胜利动画 | 连珠脉冲 + 彩带飘落 + 落子动画 |
| 13 | 触觉反馈 | 安卓震动（桌面端自动跳过） |
| 14 | 每步限时 | 10/30/60/120 秒倒计时，超时判负 |
| 15 | 联机房间 | 创建房间（显示本机 IP）/ 加入房间 + 实时聊天 |
| 16 | 新增主题 | 木质/深色/简约/星空/海洋 + 网格线颜色 |
| 17 | 随机开局 | AI 先手可选天元/星位/随机落子 |
| 18 | 中英文切换 | 界面语言一键切换 |
| 19 | 棋盘缩放拖动 | 双指缩放 + 单指拖动 |

其他保留/完善：双人同屏、六子棋、开局库、坐标/序号显示、SGF 导出、
全屏、快捷键（R 重开 / U 悔棋 / S 保存 / F 全屏）。

## 📱 安卓 16 兼容性说明

`buildozer.spec` 关键配置：

```ini
android.api = 36            ; targetSdk = 安卓 16
android.minapi = 24         ; 安卓 7.0+
android.ndk = 28c           ; NDK r28 默认 16KB 对齐编译
android.archs = arm64-v8a   ; 16KB 对齐只要求 64 位，覆盖 99%+ 安卓16 手机
p4a.branch = develop        ; python-for-android 开发分支（16KB 修复）
requirements = python3==3.11.7,kivy==2.3.1,plyer
```

> 参考：kivy/python-for-android#3165（16KB 页大小支持），社区验证
> `NDK 28c + arm64-v8a + p4a develop + kivy 2.3.1` 可产出符合 16KB 要求的 APK。

## 🧪 本地测试

```bash
# 核心逻辑单测（无需 Kivy）
python3 tests/test_core.py

# 无头 UI 集成测试（需 xvfb + kivy）
xvfb-run -a python3 tests/headless_app_test.py
```

## 📁 文件结构

```
main.py            # Kivy 界面与玩法（19 项新功能）
game_core.py       # 纯逻辑核心：胜负/禁手/AI/残局/棋谱/统计/成就
network.py         # 局域网联机（创建/加入房间 + 聊天）
buildozer.spec     # 安卓 16 打包配置
.github/workflows/build.yml  # GitHub Actions 自动打包 + 16KB 校验
NotoSansCJK-Regular.otf     # 中文字体
tests/             # 单元测试与无头集成测试
```

## ⚠️ 备注

- 联机需两台手机在同一局域网（或公网 IP + 端口转发 8888）。
- 若要在 Google Play 上架，请用 `buildozer android release` 生成
  release AAB 并自行签名（工作流默认产出可安装的 debug APK）。
